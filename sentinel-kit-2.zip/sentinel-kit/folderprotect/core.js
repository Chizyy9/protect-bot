'use strict';

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const DEFAULT_INTEG_FILE = path.join(process.cwd(), '.integ');

// ---------- util path ----------
function toPosix(p) {
  return p.split(path.sep).join('/');
}

function isExcluded(fullPath, excludeList) {
  const normalized = toPosix(path.resolve(fullPath));
  return excludeList.some((ex) => {
    const exResolved = toPosix(path.resolve(ex));
    return normalized === exResolved || normalized.startsWith(exResolved + '/');
  });
}

// ---------- kumpulkan semua file ----------
function collectFiles(targets, excludeList) {
  const files = [];

  function walk(current) {
    if (isExcluded(current, excludeList)) return;
    let stat;
    try {
      stat = fs.statSync(current);
    } catch (e) {
      return; // path tidak ada, lewati
    }
    if (stat.isDirectory()) {
      const entries = fs.readdirSync(current);
      for (const entry of entries) walk(path.join(current, entry));
    } else if (stat.isFile()) {
      files.push(path.resolve(current));
    }
  }

  for (const t of targets) walk(t);

  return Array.from(new Set(files)).sort();
}

// ---------- hashing: HMAC-SHA512 ----------
function hashFile(filePath, secretKey) {
  const content = fs.readFileSync(filePath);
  const relPath = toPosix(path.relative(process.cwd(), filePath));
  return crypto
    .createHmac('sha512', secretKey)
    .update(relPath)
    .update(content)
    .digest('hex');
}

function buildManifest(listProtectedFileAndFolder, excludeFileAndFolder, secretKey) {
  const files = collectFiles(listProtectedFileAndFolder, excludeFileAndFolder);
  const entries = {};
  for (const f of files) {
    const relPath = toPosix(path.relative(process.cwd(), f));
    entries[relPath] = hashFile(f, secretKey);
  }
  const sortedKeys = Object.keys(entries).sort();
  const canonical = sortedKeys.map((k) => `${k}:${entries[k]}`).join('|');
  const manifestHash = crypto.createHmac('sha512', secretKey).update(canonical).digest('hex');
  return { entries, manifestHash, generatedAt: new Date().toISOString() };
}

// ---------- enkripsi manifest: AES-256-GCM (authenticated) + scrypt key derivation ----------
function encryptPayload(json, secretKey) {
  const salt = crypto.randomBytes(16);
  const key = crypto.scryptSync(secretKey, salt, 32);
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', key, iv);
  const encrypted = Buffer.concat([cipher.update(JSON.stringify(json), 'utf8'), cipher.final()]);
  const authTag = cipher.getAuthTag();
  return JSON.stringify({
    salt: salt.toString('hex'),
    iv: iv.toString('hex'),
    tag: authTag.toString('hex'),
    data: encrypted.toString('hex'),
  });
}

function decryptPayload(raw, secretKey) {
  const parsed = JSON.parse(raw);
  const salt = Buffer.from(parsed.salt, 'hex');
  const key = crypto.scryptSync(secretKey, salt, 32);
  const iv = Buffer.from(parsed.iv, 'hex');
  const decipher = crypto.createDecipheriv('aes-256-gcm', key, iv);
  decipher.setAuthTag(Buffer.from(parsed.tag, 'hex'));
  // decipher.final() otomatis throw kalau authTag tidak cocok -> deteksi tamper di level enkripsi
  const decrypted = Buffer.concat([
    decipher.update(Buffer.from(parsed.data, 'hex')),
    decipher.final(),
  ]);
  return JSON.parse(decrypted.toString('utf8'));
}

// ---------- API murni: generateIntegFile ----------
function generateIntegFile(options) {
  const {
    listProtectedFileAndFolder,
    excludeFileAndFolder = [],
    secretKey,
    integFile = DEFAULT_INTEG_FILE,
  } = options || {};

  if (!secretKey) throw new Error('[sentinel-kit] secretKey wajib diisi');
  if (!Array.isArray(listProtectedFileAndFolder) || listProtectedFileAndFolder.length === 0) {
    throw new Error('[sentinel-kit] listProtectedFileAndFolder wajib diisi');
  }

  const manifest = buildManifest(listProtectedFileAndFolder, excludeFileAndFolder, secretKey);
  const payload = encryptPayload(manifest, secretKey);
  fs.writeFileSync(integFile, payload, 'utf8');

  return {
    integFile,
    totalFiles: Object.keys(manifest.entries).length,
    generatedAt: manifest.generatedAt,
  };
}

// ---------- API murni: verifyIntegrity (TIDAK membunuh proses, cuma lapor hasil) ----------
function verifyIntegrity(options) {
  const {
    listProtectedFileAndFolder,
    excludeFileAndFolder = [],
    secretKey,
    integFile = DEFAULT_INTEG_FILE,
    verbose = false,
  } = options || {};

  if (!secretKey) throw new Error('[sentinel-kit] secretKey wajib diisi');

  const result = { ok: false, reason: null, mismatched: [], missing: [], added: [] };

  if (!fs.existsSync(integFile)) {
    result.reason = 'INTEG_FILE_NOT_FOUND';
    return verbose ? result : false;
  }

  let storedManifest;
  try {
    const raw = fs.readFileSync(integFile, 'utf8');
    storedManifest = decryptPayload(raw, secretKey);
  } catch (e) {
    // termasuk kasus authTag GCM tidak cocok (file .integ dimodifikasi manual)
    result.reason = 'INTEG_FILE_CORRUPT_OR_WRONG_KEY';
    return verbose ? result : false;
  }

  const sortedKeys = Object.keys(storedManifest.entries).sort();
  const canonical = sortedKeys.map((k) => `${k}:${storedManifest.entries[k]}`).join('|');
  const expectedManifestHash = crypto
    .createHmac('sha512', secretKey)
    .update(canonical)
    .digest('hex');

  if (expectedManifestHash !== storedManifest.manifestHash) {
    result.reason = 'MANIFEST_TAMPERED';
    return verbose ? result : false;
  }

  const currentManifest = buildManifest(listProtectedFileAndFolder, excludeFileAndFolder, secretKey);

  const storedKeys = new Set(Object.keys(storedManifest.entries));
  const currentKeys = new Set(Object.keys(currentManifest.entries));

  for (const k of storedKeys) {
    if (!currentKeys.has(k)) {
      result.missing.push(k);
    } else if (storedManifest.entries[k] !== currentManifest.entries[k]) {
      result.mismatched.push(k);
    }
  }
  for (const k of currentKeys) {
    if (!storedKeys.has(k)) result.added.push(k);
  }

  result.ok =
    result.mismatched.length === 0 && result.missing.length === 0 && result.added.length === 0;
  if (!result.ok && !result.reason) result.reason = 'FILES_CHANGED';

  return verbose ? result : result.ok;
}

module.exports = {
  generateIntegFile,
  verifyIntegrity,
};
